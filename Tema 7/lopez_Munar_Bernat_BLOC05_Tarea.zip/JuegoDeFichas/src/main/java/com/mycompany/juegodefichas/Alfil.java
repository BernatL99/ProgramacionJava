/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.juegodefichas;

/**
 * Creamos la clase Alfil, donde crearemos la clase hija de ficha
 * @author berna
 */
public class Alfil extends Ficha{
    private final char nombre = 'A';
    private int vidasExtra;
    
    public Alfil(){
    }
    
    public Alfil(int posicionX, int posicionY, String color, int vidasExtra){
        super(posicionX,posicionY,color);
        this.vidasExtra = vidasExtra;
    }
        
    public int getVidasExtra(){
        return vidasExtra;
    }
    public void setVidasExtra(int vidasExtra){
        this.vidasExtra = vidasExtra;
    }
    
    @Override
        public char getNombre(){
        return nombre;
    }
        

    @Override
        public boolean moverA(Casilla casilla) {
            int xActual = getPosicionX();
            int yActual = getPosicionY();
            int xDestino = casilla.getFila();
            int yDestino = casilla.getColumna();
            if(xActual == xDestino && yActual == yDestino ){
                return false;
            }
            
            int dx = Math.abs(xDestino - xActual);
            int dy = Math.abs(yDestino - yActual);
            return dx == dy;
        }    
}
