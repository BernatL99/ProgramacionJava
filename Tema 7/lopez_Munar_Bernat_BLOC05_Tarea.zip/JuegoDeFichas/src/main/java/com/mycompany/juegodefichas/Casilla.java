/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.juegodefichas;

/**
 *Creamos la clase casilla para almacenar los datos de la misma
 * @author Bernat López Munar
 */
public class Casilla {
    private int fila = 5, columna = 5;

    public Casilla() {
    }
    public Casilla(int fila, int columna){
        this.fila = fila;
        this.columna = columna;
    }
    
    public int getFila(){
        return fila;
    }

    public int getColumna(){
        return columna;
    }
}
