/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.juegodefichas;

/**
 * Creamos la clase Caballo, donde crearemos la clase hija de ficha
 * @author Bernat Lope Munar
 */
public class Caballo extends Ficha {
    private final char nombre = 'C';
    
    public Caballo(){    
    }
    
    public Caballo(int posicionX, int posicionY, String color){
        super(posicionX,posicionY,color);
    }
    
    @Override
        public char getNombre(){
        return nombre;
    }
    
    @Override
        public boolean moverA(Casilla casilla) {
            
            int xActual = getPosicionX();
            int yActual = getPosicionY();
            int xDestino = casilla.getFila();
            int yDestino = casilla.getColumna();
            if (xActual == xDestino && yActual == yDestino){
                return false;
            }
            int dx = Math.abs(xDestino - xActual);
            int dy = Math.abs(yDestino - yActual);
            return (dx == 2 && dy == 1) || (dx == 1 && dy == 2);
    } 
}
