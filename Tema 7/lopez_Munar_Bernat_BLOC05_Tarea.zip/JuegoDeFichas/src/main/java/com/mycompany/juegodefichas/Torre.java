/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.juegodefichas;

/**
 * Creamos la clase Torre, donde crearemos la clase hija de ficha
 * @author Bernat Lopez Munar
 */
public class Torre extends Ficha{
    private char nombre = 'T';
    private int turnosExtra;
    
    public Torre(){    
    }
    
    public Torre(int posicionX, int posicionY, String color, int turnosExtra){
        super(posicionX,posicionY,color);
        this.turnosExtra = turnosExtra;
    }
    
    public int getTurnosExtra(){
        return turnosExtra;
    }
    public void setTurnosExtra(int turnosExtra){
        this.turnosExtra = turnosExtra;
    }
    
    
    public boolean hasTurnosExtra(){
        return turnosExtra > 0;
    }
    public void consumeTurnoExtra(){
        if (turnosExtra > 0) turnosExtra--;
    }

    
    @Override
        public char getNombre(){
        return nombre;
    }

    @Override
        public boolean moverA(Casilla casilla) {         
            int xActual = getPosicionX();
            int yActual = getPosicionY();
            int xDestino = casilla.getFila();
            int yDestino = casilla.getColumna();
            if (xActual == xDestino && yActual == yDestino){
                return false;
            }
            return (xActual == xDestino) || (yActual == yDestino);
        }
    
}
