/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.juegodefichas;

/**
 * Creamos la clase Ficha, donde crearemos la clase madre 
 * @author Bernat Lopez Munar
 */
public abstract class Ficha {
    private int posicionX, posicionY;
    private String color;
    
    public Ficha(){    
    }
    public Ficha(int posicionX,int posicionY, String color){
        this.posicionX = posicionX;
        this.posicionY = posicionY;
        this.color = color;
    }
    
    public int getPosicionX(){
        return posicionX;
    }
    public void setPosicionX(int posicionX){
        this.posicionX = posicionX;
    }
    
    public int getPosicionY(){
        return posicionY;
    }
    public void setPosicionY(int posicionY){
        this.posicionY = posicionY;
    }
    
    public String getColor(){
        return color;
    }
    public void setColor(String color){
        this.color = color;
    }
    
    public abstract boolean moverA(Casilla casilla);
    public abstract char getNombre();
}
