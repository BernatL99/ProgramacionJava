/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package vista;

import controlador.CustomerDAO;
import controlador.PaymentDAO;
import modelo.Customer;
import modelo.Payment;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Nota: Código main donde se pedirás y se ejecutarán los datos
 * @author Bernat Lopez Munar
 */
public class PagosBernatLopez {
    private static final String URL = "jdbc:mariadb://localhost:3306/classicmodels?user=root&password=1234";
    private static final Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion = 0;
        do {
            System.out.println("\n--- MENÚ DE GESTIÓN DE PAGOS ---");
            System.out.println("1. Clientes con más pagos registrados");
            System.out.println("2. Generar informe de pagos de un cliente (.txt)");
            System.out.println("3. Modificar el importe de un pago");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(teclado.nextLine());
                switch (opcion) {
                    case 1: 
                        opcion1();
                        break;
                    case 2: 
                        opcion2();
                        break;
                    case 3: 
                        opcion3();
                        break;
                    case 4: 
                        System.out.println("Saliendo del programa...");
                        break;
                    default: System.out.println("Opción no válida");
                } 
            } catch (NumberFormatException e) {
                System.out.println("Error: introduzca un número válido");
            }
        } while (opcion != 4);
    }

    private static void opcion1() {
        System.out.print("Cuántos clientes desea ver?: ");
        ArrayList<Customer> customers = null;
        int limite = 0;
        try {
            System.out.print(">");
            limite = Integer.parseInt(teclado.nextLine());
            CustomerDAO customerDAO = new CustomerDAO(URL);
            customers = customerDAO.getCustomers(limite);
            
            for (Customer c : customers) {
                System.out.println(c);
            }
        } catch (SQLException | NumberFormatException ex) {
            System.out.println("Error en BD: " + ex.getMessage());
        }

    }

    private static void opcion2() {
        int customerNumber = 0;
        System.out.println("Ingrese el código de cliente");
        try{
          customerNumber = Integer.parseInt(teclado.nextLine());
          PaymentDAO paymentDAO = new PaymentDAO(URL);
          paymentDAO.exportarClienteATXT(customerNumber);
        }catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void opcion3() {
        int customerNumber = 0;
        String checkNumber = null;
        int opcion = 0;
        boolean existe = false;
        do{
            try{
                System.out.println("Ingrese el código de cliente");
                System.out.print(">");
                customerNumber = Integer.parseInt(teclado.nextLine());
                System.out.println("Ingrese el código del pago");
                System.out.print(">");
                checkNumber = teclado.nextLine();
                PaymentDAO paymentDAO = new PaymentDAO(URL);
                existe = paymentDAO.existeFactura(customerNumber,checkNumber);
            }catch(Exception e){
                System.out.println("Ponga los datos correctamente");
            }
            if(existe== false){
                System.out.println("Cliente o factura errónea, intente de nuevo");
            }
        }while(!existe);
        
        System.out.println("1. Suma\n2. Resta");
        while(opcion!=1 && opcion!=2){
            try{
                opcion = Integer.parseInt(teclado.nextLine()); 
            }catch(Exception e){
                System.out.println("Elije entre 1 o 2");
            }
        }
        switch(opcion){
            case 1:
                suma(customerNumber,checkNumber);
                break;
            case 2:
                resta(customerNumber,checkNumber);
                break;
        }
    }
    
    private static void suma(int customerNumber,String checkNumber) {
        double cantidadModifcar = 0;
        boolean comprobacion = true;
        System.out.println("Pon el monto a sumar");
        while(comprobacion){
            System.out.print(">");
            try{
                cantidadModifcar = Double.parseDouble(teclado.nextLine());
                if(cantidadModifcar <= 0){
                    System.out.println("No puedes poner un 0 ni una cantidad negativa");
                }else{
                    comprobacion = false;
                }
            }catch(NumberFormatException e){
                System.out.println("Solo se permiten números");
            }
        }
        
        PaymentDAO paymentDAO = new PaymentDAO(URL);
        Payment payment = paymentDAO.sumarFactura(customerNumber,checkNumber,cantidadModifcar);
        double amountActual = cantidadModifcar + payment.getAmount();
        System.out.println(payment + "\nMonto a sumar: " + cantidadModifcar +
                "\nCantidad total: "+ amountActual);
         
    }

    private static void resta(int customerNumber,String checkNumber) {
        double cantidadModifcar = 0;
        boolean comprobacion = true;
        System.out.println("Pon el monto a restar");
        while(comprobacion){
            System.out.print(">");
            try{
                cantidadModifcar = Double.parseDouble(teclado.nextLine());
                if(cantidadModifcar <= 0){
                    System.out.println("No puedes poner un 0 ni una cantidad negativa");
                }else{
                    comprobacion = false;
                }
            }catch(NumberFormatException e){
                System.out.println("Solo se permiten números");
            }
        }
        
        PaymentDAO paymentDAO = new PaymentDAO(URL);
        Payment payment = paymentDAO.restarFactura(customerNumber,checkNumber,cantidadModifcar);
        if(payment == null){
            System.out.println("Se ha producido un error, intentelo de nuevo"); 
        }else if(payment.getAmount()< 0){
            System.out.println("El pago no puede quedar en negativo. Reinicie la operación");
        }else{
            double amountActual = payment.getAmount() - cantidadModifcar;
            String cantidadDosDecimales = String.format("%.2f", amountActual);
        
            System.out.println(payment + "\nMonto a restar: " + cantidadModifcar +
                    "\nCantidad total: "+ cantidadDosDecimales);   
        }
       
    }
}
