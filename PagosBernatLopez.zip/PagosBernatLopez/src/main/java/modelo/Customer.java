/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 * Nota: Declaración de la clase Customer
 * @author Bernat López Munar
 */
public class Customer {
    private int customerNumber;
    private String customerName;
    private int numPagaments;
    private double totalPagats;
    
    
    public Customer(int customerNumber, String customerName, int numPagaments, double totalPagats) {
        this.customerNumber = customerNumber;
        this.customerName = customerName;
        this.numPagaments = numPagaments;
        this.totalPagats = totalPagats;
    }

    public int getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(int customerNumber) {
        this.customerNumber = customerNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getNumPagaments() {
        return numPagaments;
    }

    public void setNumPagaments(int numPagaments) {
        this.numPagaments = numPagaments;
    }

    public double getTotalPagats() {
        return totalPagats;
    }

    public void setTotalPagats(double totalPagats) {
        this.totalPagats = totalPagats;
    }

    @Override
    public String toString() {
        return "Customer{" + "customerNumber=" + customerNumber + ", customerName=" + customerName + ", numPagaments=" + numPagaments + ", totalPagats=" + totalPagats + '}';
    }

}
