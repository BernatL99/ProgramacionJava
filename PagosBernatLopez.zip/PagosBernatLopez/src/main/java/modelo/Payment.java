/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.sql.Date;
/**
 * Nota: Declaración de la clase Payment
 * @author Bernat Lopez Munar
 */
public class Payment {
    private String checkNumber;
    private int customerNumber;
    private Date paymentDate;
    private double amount;
    
    public Payment(){
    }
    
    public Payment(String checkNumber, int customerNumber , Date paymentDate, double amount){
        this.checkNumber = checkNumber;
        this.customerNumber = customerNumber;
        this.paymentDate = paymentDate;
        this.amount = amount;    
    }
    
    public String getCheckNumber(){
        return checkNumber;
    }
    public void setCheckNumber(String checkNumber){
        this.checkNumber = checkNumber;
    }
    
    public int getCustomerNumber() {
        return customerNumber;
    }
    public void setCustomerNumber(int customerNumber) {
        this.customerNumber = customerNumber;
    }
    
    public Date getPaymentDate(){
        return paymentDate;
    }
    public void setPaymentDate(Date paymentDate){
        this.paymentDate = paymentDate;
    }
    
    public double getAmount(){
        return amount;
    }
    public void setAmount(double amount){
        this.amount = amount;
    }
    
    @Override
    public String toString(){
        return "--- Factura:---\nIDcliente: " +customerNumber+ "\nIDfactura: " +checkNumber+
                "\nFecha de creación: " + paymentDate + "\nPago inicial: " + amount;
    }
    
}
