/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Payment;
import java.sql.*;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;
/**
 * Nota: Conexión con la base de datos y la tabla payments
 * @author Bernat López Munar
 */
public class PaymentDAO {

    private String url;

    public PaymentDAO(String url) {
        this.url = url;
    }

    public void exportarClienteATXT(int customerNumber) {
        String sql = "SELECT c.customerNumber,\n"
                + "c.customerName,\n"
                + "COUNT(p.checkNumber) AS numPagos,\n"
                + "SUM(p.amount) AS totalPagado\n"
                + "FROM customers c\n"
                + "LEFT JOIN payments p\n"
                + "       ON c.customerNumber = p.customerNumber\n"
                + "WHERE c.customerNumber = ?\n"
                + "GROUP BY c.customerNumber, c.customerName";

        try (Connection con = DriverManager.getConnection(url); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, customerNumber);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("customerNumber");
                String nombre = rs.getString("customerName");
                int numPagos = rs.getInt("numPagos");
                double totalPagado = rs.getDouble("totalPagado");

                String nombreArchivo = "cliente_" + id + ".txt";
                FileWriter fw = new FileWriter(nombreArchivo);
                fw.write("INFORME DEL CLIENTE\n");
                fw.write("=========================\n");
                fw.write("Número de cliente: " + id + "\n");
                fw.write("Nombre: " + nombre + "\n");
                fw.write("Número de pagos:" + numPagos + "\n");
                fw.write("Total pagado: " + totalPagado + "€\n");
                fw.close();
                System.out.println("Archivo TXT generado: " + nombreArchivo);
            } else {
                System.out.println("No existe un cliente con número:" + customerNumber);
            }
        } catch (SQLException | IOException e) {
            System.out.println("!!!Error al generar archivo TXT¡¡¡");
            e.printStackTrace();
        }
    }

    public boolean existeFactura(int customerNumber, String checkNumber) {
        String sql = "SELECT p.customerNumber, p.checkNumber\n"
                + "FROM customers c\n"
                + " JOIN payments p ON p.customerNumber = c.customerNumber\n"
                + "WHERE c.customerNumber = ? AND p.checkNumber = ?";

        try (Connection con = DriverManager.getConnection(url); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, customerNumber);
            ps.setString(2, checkNumber);
            ResultSet rs = ps.executeQuery();
            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
            return false;

        }
    }
    
    public Payment sumarFactura(int customerNumber, String checkNumber, double cantidadModifcar){
        double cantidad = 0;
        Payment payment = new Payment();
        String sqlAlmacenamnientoObjeto = "SELECT customerNumber, checkNumber, paymentDate, amount"
               + " FROM payments WHERE customerNumber = ? AND checkNumber = ?";  
        
        try(Connection connection = DriverManager.getConnection(url); 
                PreparedStatement ejecucionConsultas = connection.prepareStatement(sqlAlmacenamnientoObjeto)){
            ejecucionConsultas.setInt(1, customerNumber);
            ejecucionConsultas.setString(2,checkNumber);
            ResultSet resultado = ejecucionConsultas.executeQuery();
            
            if(resultado.next()){
                int numeroCliente = resultado.getInt("customerNumber");
                String numeroFactura = resultado.getString("checkNumber");
                Date fechaPago = resultado.getDate("paymentDate");
                cantidad = resultado.getDouble("amount");
                
                payment = new Payment(numeroFactura,numeroCliente,fechaPago,cantidad);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        String sql ="UPDATE payments SET amount = amount + ?"+
              " WHERE customerNumber = ? AND checkNumber =?";
      
        try(Connection con = DriverManager.getConnection(url); PreparedStatement ps = con.prepareStatement(sql)){
          ps.setDouble(1, cantidadModifcar);
          ps.setInt(2,customerNumber);
          ps.setString(3, checkNumber);
          ps.executeUpdate();
          return payment;
          
        }catch(Exception e){
        e.printStackTrace();
        return payment;
        }
    }
    
    public Payment restarFactura(int customerNumber, String checkNumber, double cantidadModifcar){
        double cantidad = 0;
        Payment payment = new Payment();
        String sqlAlmacenamnientoObjeto = "SELECT customerNumber, checkNumber, paymentDate, amount"
               + " FROM payments WHERE customerNumber = ? AND checkNumber = ?";  
        
        try(Connection connection = DriverManager.getConnection(url); 
                PreparedStatement ejecucionConsultas = connection.prepareStatement(sqlAlmacenamnientoObjeto)){
            ejecucionConsultas.setInt(1, customerNumber);
            ejecucionConsultas.setString(2,checkNumber);
            ResultSet resultado = ejecucionConsultas.executeQuery();
            
            if(resultado.next()){
                int numeroCliente = resultado.getInt("customerNumber");
                String numeroFactura = resultado.getString("checkNumber");
                Date fechaPago = resultado.getDate("paymentDate");
                cantidad = resultado.getDouble("amount");
                double siSaleNegativo = cantidad - cantidadModifcar;
                if(siSaleNegativo < 0){
                   return  payment = new Payment(numeroFactura,numeroCliente,fechaPago,siSaleNegativo); 
                }            
                payment = new Payment(numeroFactura,numeroCliente,fechaPago,cantidad);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        String sql ="UPDATE payments SET amount = amount - ?"+
              " WHERE customerNumber = ? AND checkNumber =?";
      
        try(Connection con = DriverManager.getConnection(url); PreparedStatement ps = con.prepareStatement(sql)){
          ps.setDouble(1, cantidadModifcar);
          ps.setInt(2,customerNumber);
          ps.setString(3, checkNumber);
          ps.executeUpdate();
          return payment;
          
        }catch(Exception e){
        e.printStackTrace();
        return payment;
        }
    }
}
