/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Customer;
import java.sql.*;
import java.util.ArrayList;

/**
 * Nota: Conexión con la base de datos y la tabla customers
 * @author Bernat Lopez Munar
 */
public class CustomerDAO {
    private String url;
    
    public CustomerDAO(String url) {
        this.url = url;
    }
    
    public ArrayList<Customer> getCustomers(int limite) throws SQLException {
        ArrayList<Customer> resultat = new ArrayList<>();
        

        Connection conexion = DriverManager.getConnection(url);
        

        String sql = "SELECT c.customerNumber, c.customerName, " +
                     "COUNT(p.checkNumber) AS numPagaments, SUM(p.amount) AS totalPagat " +
                     "FROM customers c " +
                     "LEFT JOIN payments p ON c.customerNumber = p.customerNumber " +
                     "GROUP BY c.customerNumber " +
                     "ORDER BY totalPagat DESC " +
                     "LIMIT ?";

        PreparedStatement st = conexion.prepareStatement(sql);
        st.setInt(1, limite);
        

        ResultSet rs = st.executeQuery();
        
        while (rs.next()) {
            // 
            Customer customer = new Customer(
                rs.getInt("customerNumber"),
                rs.getString("customerName"),
                rs.getInt("numPagaments"),
                rs.getDouble("totalPagat")
            );
            resultat.add(customer);
        }
        conexion.close();
        return resultat;
    }
    
}
