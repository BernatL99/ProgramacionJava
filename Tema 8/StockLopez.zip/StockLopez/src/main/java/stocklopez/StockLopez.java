/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package stocklopez;

/**
 * Programa para almacenar artículos con código y almacenarlos de la Z a la A
 * @author Bernat Lopez munar
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class StockLopez {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        List<Articulo> listaArticulos = new ArrayList<>();
        System.out.println("Introduce códigos de articulos. Si pones 000 terminará");
        while(true){
            System.out.println("Pon un código");
            String codigo = in.nextLine().trim();
            if(codigo.equals("000")){
                break;
            }
            if(codigo.isEmpty()){
                continue;    
            }
            Articulo existente = buscarCodigo(listaArticulos,codigo);
            if(existente == null){
                System.out.print("Descripción para " + codigo + ": ");
                String descripcion = in.nextLine().trim();
                if(descripcion.isEmpty()){
                    descripcion = codigo;
                }
                Articulo nuevo = new Articulo(codigo,descripcion,1);
                listaArticulos.add(nuevo);
            }
            else{
                existente.setCantidad(existente.getCantidad()+1);
            }
        }
        Collections.sort(listaArticulos);
        System.out.println("\nArtículos ordenados por código (Z -> A):");
        for(Articulo a : listaArticulos){
            System.out.println(a);
        }
    }
    
    private static Articulo buscarCodigo(List<Articulo> listaArticulos, String codigo){
        for(Articulo a : listaArticulos){
            if(a.getCodigo() != null && a.getCodigo().equalsIgnoreCase(codigo)){
                return a;
            }
        }
        return null;
    }
}
