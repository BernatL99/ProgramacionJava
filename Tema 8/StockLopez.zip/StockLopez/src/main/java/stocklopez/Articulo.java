/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stocklopez;

/**
 * Creacion de la clase articulo
 * @author Bernat Lopez Munar
 */
public class Articulo implements Comparable<Articulo>{
    private String codigo;
    private String descripcion;
    private int cantidad;
    
    public Articulo(){    
    }
    public Articulo(String codigo, String descripcion, int cantidad){
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.cantidad = cantidad;    
    }
    
    public String getCodigo(){
        return codigo;
    }
    public void setCodigo(String codigo){
        this.codigo = codigo;
    }
    
    public String getDescripcion(){
        return descripcion;
    }
    public void setDescripcion(String descripcion){
        this.descripcion = descripcion;
    }
    
    public int getCantidad(){
        return cantidad;
    }
    public void setCantidad(int cantidad){
        this.cantidad = cantidad;
    }
    
    @Override
    public int compareTo(Articulo articulo){
        if (this.codigo == null && articulo.codigo == null) return 0;
        if (this.codigo == null) return 1;
        if (articulo.codigo == null) return -1;
        return articulo.codigo.compareToIgnoreCase(this.codigo);
    }
    
    @Override
    public String toString(){
        return String.format("%s | %s | %d", codigo, descripcion, cantidad);
    }
}
