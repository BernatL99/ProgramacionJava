/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package bloc06ejer01;

/**
 *
 * @author Bernat López Munar
 */
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class Bloc06Ejer01 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        List<String> listaPalabras = new ArrayList<String>();
        Map<Character,Integer>cantidadPrimeraLetra = new HashMap<>();
        listaPalabras = palabras();
        cantidadPrimeraLetra = cantidadPrimeraLetra(listaPalabras);
        System.out.println("---------Palabras Introducidas---------\n");
        for(String palabra:listaPalabras){
            System.out.println(palabra);
        }
        System.out.println("\n---------Cantidad de primeras letras---------\n");
        for(Character letra:cantidadPrimeraLetra.keySet() ){
            System.out.println(letra + " = " +cantidadPrimeraLetra.get(letra));
        }
    }
    
    public static List<String> palabras(){
        Scanner in = new Scanner(System.in);
            List<String> listaPalabras = new ArrayList<String>();
            boolean bucle = true;
            while(bucle){
                String finalizar = "finalizar";
                System.out.println("Introduce una palabra");
                String palabra = in.nextLine().trim();
                if(palabra.equals(finalizar)){
                    return listaPalabras;
                }
                else if(!palabra.matches("^(?!\\s)\\S+$")){
                    System.out.println("No se puede introducir espacios en blanco");
                }
                else if(palabra.matches("^[0-9].*")){
                    System.out.println("No puede empezar con un número");
                }
                else{
                    listaPalabras.add(palabra);
                }
            }
            return listaPalabras;
    }
    
    public static Map<Character, Integer> cantidadPrimeraLetra(List<String>listaPalabras){
        Map<Character,Integer>cantidadPrimeraLetra = new HashMap<>();
        char primeraLetra;
        for(String palabra:listaPalabras){
            primeraLetra = palabra.charAt(0);
            cantidadPrimeraLetra.put(primeraLetra, cantidadPrimeraLetra.getOrDefault(primeraLetra, 0)+1);
        }
        return cantidadPrimeraLetra;
    }
}
