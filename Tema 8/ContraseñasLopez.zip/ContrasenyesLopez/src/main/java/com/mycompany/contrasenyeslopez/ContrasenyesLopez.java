/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.contrasenyeslopez;

/**
 * Programa para crear contraseñas de manera aleatoria definindo la cantidad de carácteres
 * @author Bernat López
 */
import java.util.Scanner;
import java.util.HashSet;
import java.util.Set;
import java.util.Random;
import java.util.InputMismatchException;
public class ContrasenyesLopez {
    
    private static final int MAX_INTENTOS_POR_CONTRASENA = 10;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int numeroContraseñas = 0;
        int longitudContraseñas = 0;
        String contraseña;
        boolean datoCorrecto = true;
        Set<String> contraseñas = new HashSet<>();
        while(datoCorrecto){
            System.out.println("¿Cuantas contraseñas quieres crear?");
            try{
                numeroContraseñas = in.nextInt();
                in.nextLine();
                datoCorrecto = false;
            }
            catch(NumberFormatException e){
                System.out.println("Entrada no válida. Debes escribir un número entero. Inténtalo de nuevo."); 
            }    
        }
        datoCorrecto = true;
        while(datoCorrecto){
            System.out.println("¿Cuantos caracteres tiene que tener las contraseñas?");
            try{
                longitudContraseñas = in.nextInt();
                in.nextLine();
                datoCorrecto = false;
            }
            catch(NumberFormatException e){
                System.out.println("Entrada no válida. Debes escribir un número entero. Inténtalo de nuevo."); 
            }    
        }
        int colisiones = 0;
        int totalIntentos = 0;
        boolean falloPorIntentos = false;
        for (int i = 0; i < numeroContraseñas; i++) {
            boolean agregada = false;
            for (int intento = 1; intento <= MAX_INTENTOS_POR_CONTRASENA; intento++) {
                contraseña = creacionContraseña(longitudContraseñas);
                totalIntentos++;

                if (contraseñas.add(contraseña)) {
                    System.out.printf("(%d/%d)Añadida: %s%n",
                            contraseñas.size(), numeroContraseñas, contraseña);
                    agregada = true;
                    break;
                } else {
                    colisiones++;
                    System.out.printf("(%d/%d)Repetida (intento %d): %s%n",
                            Math.min(contraseñas.size() + 1, numeroContraseñas), numeroContraseñas, intento, contraseña);
                }
            }            
            if (!agregada) {
                System.out.println("\n No se han podido generar todas las contraseñas solicitadas (se alcanzó el máximo de 10 intentos por contraseña).");
                System.out.printf("Se generaron %d de %d contraseñas solicitadas.%n", contraseñas.size(), numeroContraseñas);
                falloPorIntentos = true;
                break;
            }
            if (contraseñas.size() == numeroContraseñas) {
                break;
            }
        }
        if (!falloPorIntentos && contraseñas.size() == numeroContraseñas) {
            System.out.println("\n=== Contraseñas generadas ===");
            for (String c : contraseñas) {
                System.out.println(" - " + c);
            }

            double porcentajeColisiones = (totalIntentos == 0)
                    ? 0.0
                    : (colisiones * 100.0 / totalIntentos);

            System.out.printf("Duplicados: %d de %d intentos (%.2f%%)%n",
                    colisiones, totalIntentos, porcentajeColisiones);
        }
    }
    
    public static String creacionContraseña(int longitud){
        String contraseña;
        Random random = new Random();
        char[] password = new char[longitud];
        for (int j = 0; j < longitud; j++) {    
           char c = (char) (random.nextInt(26) + 'a');    
           if (random.nextBoolean()) {
              c = Character.toUpperCase(c);
           }   
           if (random.nextBoolean()) {
              password[j] = c;    
           } else {        
              password[j] = (char) ('0' + random.nextInt(10));    
           }
        }
        contraseña = new String(password);
        
        return contraseña;   
    }
}
