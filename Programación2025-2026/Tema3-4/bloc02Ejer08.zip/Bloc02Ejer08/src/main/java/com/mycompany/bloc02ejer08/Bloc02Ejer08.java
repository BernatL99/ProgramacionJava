/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer08;

/**
 * Programa para realizar operaciones simples matemáticas
 * @author Bernat lopez Munar
 */
import java.util.Scanner;
import java.util.InputMismatchException;
public class Bloc02Ejer08 {
    public static void mostrarMenu(double numeroReal1,double numeroReal2){
        Scanner in = new Scanner(System.in);
        int Opcion = 0;
        while(Opcion < 5 || Opcion > 5){
            System.out.println("\nElije uno del siguiente menu: ");
            System.out.println("MENÚ\n1.Sumar\n2.Restar\n3.Multiplicar\n4.Dividir\n5.Salir");
            Opcion = in.nextInt();
            switch(Opcion){
                case 1:
                    sumar(numeroReal1,numeroReal2);
                    break;
                case 2:
                    restar(numeroReal1,numeroReal2);
                    break;
                case 3:
                    multiplicar(numeroReal1,numeroReal2);
                    break;
                case 4:
                    dividir(numeroReal1,numeroReal2);
                    break;
                case 5:
                    System.out.println("Cerramos programa. Buenos días");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        }
        
    }
    
    public static void sumar(double numeroReal1, double numeroReal2){
        double SUMAR =numeroReal1 + numeroReal2;
        System.out.println(numeroReal1 + "+" + numeroReal2+"="+ SUMAR); 
    }
    
    public static void restar(double numeroReal1, double numeroReal2){
        double RESTAR = numeroReal1 - numeroReal2;
        System.out.println(numeroReal1 + "-" + numeroReal2+"="+ RESTAR);
    }
    
    public static void multiplicar(double numeroReal1, double numeroReal2){
        double MULTIPLICAR = numeroReal1 * numeroReal2;
        System.out.println(numeroReal1 + "*" + numeroReal2+"="+ MULTIPLICAR);
    }
    
    public static void dividir(double numeroReal1, double numeroReal2){
        double DIVIDIR;
        if(numeroReal2 == 0){
            System.out.println("No se puede dividir entre 0");
        }
        else{
            DIVIDIR = numeroReal1 / numeroReal2;
            System.out.println(numeroReal1 + "/" + numeroReal2+"="+ DIVIDIR);
        }
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double Primer_Numero = 0, Segundo_Numero = 0;
        boolean valido = false;
        while(!valido){
            try{
                System.out.println("Introduce un número con decimales ");
                Primer_Numero = in.nextDouble();
                valido = true;
            }
            catch(InputMismatchException e){
                System.out.println("Error: Debes de introducir un número correcto");
                in.nextLine();//Usamos esto para limpiar el Scanner, si no se queda en bucle
            }
        }
        valido = false;
        while(!valido){
            try{
                System.out.println("Introduce un segundo número con decimales: ");
                Segundo_Numero = in.nextDouble();
                valido = true;
            }
            catch(InputMismatchException e){
                System.out.println("Error: Debes de introducir un número correcto");
                in.nextLine();
            }
        }
        mostrarMenu(Primer_Numero, Segundo_Numero);
        
    }
}

