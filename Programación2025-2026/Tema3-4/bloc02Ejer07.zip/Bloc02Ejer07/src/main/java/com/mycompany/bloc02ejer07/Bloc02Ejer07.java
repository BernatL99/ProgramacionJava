/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer07;

/**
 *
 * @author berna
 */
import java.util.Scanner;
public class Bloc02Ejer07 {

    public static void main(String[] args) {
        int Cantidad_Numeros,Numero = 0,Suma = 0; 
        int MINIMO = 0, MAXIMO = 0;
        double MEDIA;
        Scanner in = new Scanner(System.in);
        System.out.println("¿Que cantidad de númeos quieres añadir? ");
        Cantidad_Numeros = in.nextInt();
        for(int i = 1; i <= Cantidad_Numeros ; i++){
            System.out.println("Introduce un número ");
            Numero = in.nextInt();
            Suma += Numero;
            if(i==1){
                MINIMO = Numero;
            }
            else if(MINIMO > Numero){
                MINIMO = Numero;
            }
            else if(MAXIMO < Numero){
                MAXIMO = Numero;
            }
        }
        MEDIA = Suma/Cantidad_Numeros;
        System.out.println("La suma total es: "+ Suma + ".\nEl valor máximo es: "
        + MAXIMO+ ".\nEl valor mínimo es: " + MINIMO + ".\nLa media es: "+ MEDIA);
    }
}
