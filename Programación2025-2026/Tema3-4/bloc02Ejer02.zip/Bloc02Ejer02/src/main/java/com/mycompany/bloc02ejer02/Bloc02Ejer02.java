/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer02;
/**
 *Programa para sacar los numeros pares y cuales de estos son multiples de 6
 * @author Bernat Lopez Munar
 */
import java.util.Scanner;
public class Bloc02Ejer02 {
    public static void main(String[] args) {
        int i, n, par, suma = 0;
        System.out.println("Pon el numero de entrada");
        Scanner in = new Scanner(System.in);
        n = in.nextInt();
        System.out.println("\nLos "+ n+" primeros numeros son:");
        for(i=1;i<=n;i++){
            if(i%2==0){
                par=i;
                if(i%6==0){
                    suma=+i;    
                }
                System.out.print(par+ ", ");
            }
        }
        System.out.println("\nLa suma de los multiples de 6 suman; "+ suma);
    }
}
