/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tallerlopez;

/**
 *
 * @author berna
 */
import java.util.Scanner;
public class TallerLopez{    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        SeccionTaller SECCION1 = new SeccionTaller("Motor", 4, 1200.00);
        mostrarInfo("TallerLopez", SECCION1);
        
        SeccionTaller SECCION2 = new SeccionTaller();
        System.out.println("Introduce el nombre de la seccion:");
        SECCION2.setNombre(in.nextLine());
        
        System.out.println("Introduce el número de mecánicos");
        SECCION2.setNumeroMecanicos(in.nextInt());
        
        System.out.println("Introduce los ingresos");
        SECCION2.setIngresos(in.nextDouble());
        
        mostrarInfo("TallerLopez", SECCION2);
    }
    
    public static void mostrarInfo(String tallerNombre, SeccionTaller SECCION){
        System.out.println(tallerNombre + "\nSeccion: " +SECCION.getNombre()+
                "\nCantidad de mecanicos; "+ SECCION.getNumeroMecanicos()+
                "\nIngresos; "+ SECCION.getIngresos());
        System.out.println("\nCon un bonus medio por mecánico de: " + SECCION.CalcuarBonus() +
                "€\nUn bonus: "+ SECCION.Clasificar());
    }
    
    
}
