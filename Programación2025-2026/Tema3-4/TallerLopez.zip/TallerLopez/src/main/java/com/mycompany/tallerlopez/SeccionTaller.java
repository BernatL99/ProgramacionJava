/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallerlopez;

/**
 *Creacion del objecto con sus Getters y setters
 * @author Bernst Lopez Munar
 */
public class SeccionTaller {
    private String NOMBRE;
        private int Numero_Mecanicos;
        private double INGRESOS;
        
        public SeccionTaller(String nombre, int mecanicos, double ingresos){
            this.NOMBRE = nombre;
            this.Numero_Mecanicos = mecanicos;
            this.INGRESOS = ingresos;
        }
        public SeccionTaller(){
            this.NOMBRE="";
            this.Numero_Mecanicos = 0;
            this.INGRESOS = 0.0;
        }
        
        public String getNombre(){ return NOMBRE;}
        public void setNombre(String NOMBRE){this.NOMBRE = NOMBRE;}
        
        public int getNumeroMecanicos(){return Numero_Mecanicos;}
        public void setNumeroMecanicos(int Numero_Mecanicos){this.Numero_Mecanicos = Numero_Mecanicos;}
        
        public double getIngresos(){return INGRESOS;}
        public void setIngresos(double INGRESOS){this.INGRESOS = INGRESOS;}
        
        public double CalcuarBonus(){
            if(Numero_Mecanicos > 0){
                double REDONDEO = INGRESOS / Numero_Mecanicos;
                REDONDEO = Math.round(REDONDEO*100.00)/100.00;
                return REDONDEO ; 
            }
            else{
                return 0.0;
            }
        }
        public String Clasificar(){
            double BONUS = CalcuarBonus();
            if(BONUS < 200){
                return "Bajo";
            }
            else if(BONUS >= 200 && BONUS < 400){
                return "Medio";
            }
            else{
                return "Alto";
            }
        }
}

