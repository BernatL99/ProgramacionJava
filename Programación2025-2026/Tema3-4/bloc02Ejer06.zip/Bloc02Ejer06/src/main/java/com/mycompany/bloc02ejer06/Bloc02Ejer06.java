/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer06;

/**
 * Creamos programas para realizar un metodo y comparar que numero es mas grande
 * @author Bernat Lopez Munar
 */
import java.util.Scanner;
public class Bloc02Ejer06 {
    
    //Creamos método que devuelve el número más grande
    public static int calculaMayor(int Numero1, int Numero2){
        if(Numero1 < Numero2){
            return Numero2;
        }else if(Numero1 > Numero2) {
            return Numero1;
        }else{
            return Numero1;
        }
    }
    //Solicitamos los parámetros
    public static void main(String[] args) {
        int Numero1, Numero2, Numero3, Mayor;
        Scanner in = new Scanner(System.in);
        System.out.println("Pon tres números diferentes: ");
        Numero1 = in.nextInt();
        Numero2 = in.nextInt();
        Numero3 = in.nextInt();
        while(Numero1 != 0 && Numero2 != 0 && Numero3 != 0){
            Mayor = calculaMayor(Numero1, Numero2);
            Mayor = calculaMayor(Mayor, Numero3);
            if(Numero1 == Numero2 && Numero1 == Numero3){
               System.out.println("Los números son iguales");
            }
            else{
                System.out.println("El número mayor es: "+ Mayor);
           }
            System.out.println("Vuelve a intriducir nuevos valores: ");
            Numero1 = in.nextInt();
            Numero2 = in.nextInt();
            Numero3 = in.nextInt();
        }
    }    
}
