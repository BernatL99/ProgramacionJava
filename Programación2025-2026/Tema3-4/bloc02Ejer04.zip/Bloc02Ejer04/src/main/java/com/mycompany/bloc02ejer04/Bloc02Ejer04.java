/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer04;

/**
 *Programa para adivinar el número
 * @author Bernat lopez Munar
 */
import java.util.Scanner;
public class Bloc02Ejer04 {

    public static void main(String[] args) {
        //Declaramos als variables
        int Primer_Intervalo, Segundo_Intervalo,Num_Random,Num_Elegido;
        int Intentos = 0;
        boolean Num_Correcto = false;
        //Solicitamos los datos
        Scanner in = new Scanner(System.in);
        System.out.println("Introduce un número: ");
        Primer_Intervalo = in.nextInt();
        System.out.println("Introdice otro número: ");
        Segundo_Intervalo = in.nextInt();
        
        //Ordenamos los numeros de menor a mallor
        //Usamos (int) porque Math.random da valor double.
        if(Primer_Intervalo < Segundo_Intervalo){
            Num_Random = (int)(Math.random()*(Segundo_Intervalo - Primer_Intervalo+1))+Primer_Intervalo; 
        }
        else{
           Num_Random = (int)(Math.random()*(Primer_Intervalo - Segundo_Intervalo+1))+Segundo_Intervalo;  
        }
        
        //Empezamos el bucle. Se para si los intentos llegan a 10 o si aciertan el numero
        while(!Num_Correcto && Intentos <10 ){
            Intentos++;
            if(Primer_Intervalo < Segundo_Intervalo){
                System.out.println("Hola Bernat, introduce tu intento "+ Intentos + 
                        " para adivinar el número del intervalo " + Primer_Intervalo +
                        " "+ Segundo_Intervalo);
            }else{
                System.out.println("Hola Bernat, introduce tu intento "+ Intentos +
                        " para adivinar el número del intervalo "+ Segundo_Intervalo +
                        " " + Primer_Intervalo); 
            }
            Num_Elegido = in.nextInt();
            if(Num_Elegido > Num_Random){
                System.out.println("El numero es menor: ");
            }
            else if(Num_Elegido < Num_Random){
                System.out.println("El número es mayor: ");
            }
            else{
                System.out.println("Enhorabuena, has adivinado el número: "+ Num_Random+
                        ". \nEn el intento: "+ Intentos);
                Num_Correcto = true;
            }
        }
        if(Intentos > 10){
            System.out.println("No has adivinado el numero");
        }
    }
}
    
