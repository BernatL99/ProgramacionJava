/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer03;

/**
 * Programa para solicitar dos nombres. Puedes ser compuestos o no
 * Se tienen que organizar en orden alfabético
 * @author Bernat Lopez Munar
 */
import java.util.Scanner;
public class Bloc02Ejer03 {
    public static void main(String[] args) {
        //Declaramos las variables
        String Primer_Nombre, Segundo_Nombre, Primer_Apellido, Segundo_Apellido;
        Boolean Primer_Nombre_Compuesto, Segundo_Nombre_Compuesto, Correcto = false;
        int Posicion_Nombre1, Posicion_Nombre2;
        int Primera_Letra_Apellido1;
        Scanner in = new Scanner(System.in);
        
        //Solicitamos la entrada de los datos
        System.out.println("Pon tu nombre completo: ");
        Primer_Nombre = in.nextLine();
        System.out.println("Pon otro nombre completo: ");
        Segundo_Nombre = in.nextLine();
        
        //Comprobamos que los datos sean los correctos
        while(!Correcto){
            int Contar_Espacio_Nombre1= 0;
            int Contar_Espacio_Nombre2 = 0;
            Posicion_Nombre1 = Primer_Nombre.indexOf(' ');
            Posicion_Nombre2 = Segundo_Nombre.indexOf(' ');
            //Comprobamos la cantidad de espacios en blanco que hay en los nombres
            while(Posicion_Nombre1 != -2){
                Contar_Espacio_Nombre1++;
                Posicion_Nombre1= Primer_Nombre.indexOf(' ',Posicion_Nombre1+1);
                if(Posicion_Nombre1 == -1){
                    Posicion_Nombre1 = -2;
                }
            }
            while(Posicion_Nombre2 != -2){
                Contar_Espacio_Nombre2++;
                Posicion_Nombre2 = Segundo_Nombre.indexOf(' ',Posicion_Nombre2+1);
                if(Posicion_Nombre2 == -1){
                   Posicion_Nombre2 = -2; 
                }
            }
            //Revisamos que los nombres no sean entradas en blanco
            if(Primer_Nombre.trim().isEmpty()||Segundo_Nombre.trim().isEmpty()){
                System.out.println("Pon tu nombre correctamente");
                Primer_Nombre = in.nextLine();
                System.out.println("Pon el segundo nombre correctamente");
                Segundo_Nombre = in.nextLine();
            }
            //Si tienen menos de 2 o mas de 3 espacios, han puesto mas o menos palabras
            else if(Contar_Espacio_Nombre1 < 2 || Contar_Espacio_Nombre1 > 3
                    ||Contar_Espacio_Nombre2 < 2 || Contar_Espacio_Nombre2 > 3){
                System.out.println("Pon tu nombre correctamente");
                Primer_Nombre = in.nextLine();
                System.out.println("Pon el segundo nombre correctamente");
                Segundo_Nombre = in.nextLine();
            }
            else{
            Correcto = true;
            }
        }
        //Preguntamos si los nombre son compuestos o no
        System.out.println("\nTu nombre es compuesto? ");
        Primer_Nombre_Compuesto = in.nextBoolean();
        System.out.println("\nEl segundo nombre es compuesto? ");
        Segundo_Nombre_Compuesto = in.nextBoolean();
        System.out.println("\nPrimer nombre completo: "+Primer_Nombre+ 
                " \n¿Es un nombre compuesto? " +Primer_Nombre_Compuesto+
                " \nSegundo nombre completo: "+Segundo_Nombre+
                " \n¿Es un nombre compuesto? "+Segundo_Nombre_Compuesto);
        //Separamos los apellidos de los nombres
        if(!Primer_Nombre_Compuesto){
            Posicion_Nombre1 = Primer_Nombre.indexOf(' ');
            Primer_Apellido = Primer_Nombre.substring(Posicion_Nombre1,Primer_Nombre.length());
            Primer_Nombre = Primer_Nombre.replace(Primer_Apellido, "");
        }else{
            Posicion_Nombre1 = Primer_Nombre.indexOf(' ');
            Posicion_Nombre1 = Primer_Nombre.indexOf(' ',Posicion_Nombre1+1);
            Primer_Apellido = Primer_Nombre.substring(Posicion_Nombre1,Primer_Nombre.length());
            Primer_Nombre = Primer_Nombre.replace(Primer_Apellido, "");
        }
        if(!Segundo_Nombre_Compuesto){
            Posicion_Nombre2 = Segundo_Nombre.indexOf(' ');
            Segundo_Apellido = Segundo_Nombre.substring(Posicion_Nombre2,Segundo_Nombre.length());
            Segundo_Nombre = Segundo_Nombre.replace(Segundo_Apellido, "");
        }else{
            Posicion_Nombre2 = Segundo_Nombre.indexOf(' ');
            Posicion_Nombre2 = Segundo_Nombre.indexOf(' ',Posicion_Nombre2+1);
            Segundo_Apellido = Segundo_Nombre.substring(Posicion_Nombre2,Segundo_Nombre.length());
            Segundo_Nombre = Segundo_Nombre.replace(Segundo_Apellido, "");
        }
        //Sacamos la primera letra de los primeros apellidos para organizarlas
        Primera_Letra_Apellido1 = Primer_Apellido.compareTo(Segundo_Apellido);
        if(Primera_Letra_Apellido1 < 0){
            System.out.println("Resultado por orden alfabético:");
            System.out.println(Primer_Apellido + " " + Primer_Nombre);
            System.out.println(Segundo_Apellido + " " + Segundo_Nombre );
            
        }else{
           System.out.println("Resultado por orden alfabético:");
           System.out.println(Segundo_Apellido + " " + Segundo_Nombre );
           System.out.println(Primer_Apellido + " " + Primer_Nombre);  
        }       
    }
}
