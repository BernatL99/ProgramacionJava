/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc02ejer01;

/**
 * Programa para calcular el IMC sin redondear, redondeado a dos cifras y truncado
 * @author Bernat Lopez Munar
 */
public class Bloc02Ejer01 {

    public static void main(String[] args) {
        double PESO, ALTURA;
        PESO = 97.20;
        ALTURA = 1.82;
        System.out.println("Tu IMC es el siguiente: " + PESO/Math.pow(ALTURA, 2)+
                ".\nRedondeando el peso queda: "+ Math.round(PESO/Math.pow(ALTURA, 2)*100.00)/100.00+
                ".\ny truncandolo: "+ Math.floor(PESO/Math.pow(ALTURA, 2))+ 
                ".\n \nBernat López Munar");
        /*Multiplicamos por 100.00 y dividimos po lo mismo para sacar los dos
        decimales.
        Usamos \n para hacer los saltos de línea*/
    }
}
