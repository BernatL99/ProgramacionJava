/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inmobiliaria;

/**
 *Código principal del progrma inmobiliaria. Se pedirán los datos necesarios par la construccion de los ojetos
 * @author Bernat Lopez Munar
 */
import java.util.Scanner;
public class Inmobiliaria {
    
    public static Comprador creaComprador(){
        Scanner in = new Scanner(System.in);
        boolean verificacionComprador = false;
        Comprador comprador1 = null;
        System.out.println("Bienvenidos a la inmobiliaria Inmobiliaria");
        while(!verificacionComprador){
            try{
                System.out.println("Introduzca su nombre: ");
                String nombre = in.nextLine();
                System.out.println("Introduce tu número de teléfono: ");
                String telefono = in.nextLine();
                System.out.println("Introduce tu correo electrónico: ");
                String correo = in.nextLine();
                comprador1 = new Comprador (nombre, telefono, correo);
                verificacionComprador = true;
            }
            catch(IllegalArgumentException e){
                System.out.println("Error: " + e.getMessage());
                System.out.println("Introduce de nuevo los datos");
                in.nextLine();
            }
        }
        return comprador1;
    }
    
    public static Propiedad creaPropiedad(){
        Scanner in = new Scanner(System.in);
        boolean verificadorPropiedad = false;
        Propiedad propiedad1 = null;
        System.out.println("Ahora vamos a introducir los datos de la propiedad: ");
        while(!verificadorPropiedad){
            try{
                System.out.println("Introduce el número de referencia. ");
                String numeroReferencia = in.nextLine();
                System.out.println("Pon el tipo de propiedad: "
                        + "PISO, APARTAMENTO, CASA, LOCAL, CASA_RUSTICA, GARAGE, TERRENO, CHALET: ");
                String tipoPropiedad = in.nextLine();
                System.out.println("Introduce la localizacion de la propiedad: ");
                String localizacion = in.nextLine();
                System.out.println("Introduce el numero de habitaciones: ");
                int numeroHabitaciones = in.nextInt();
                System.out.println("Introdice el numero de baños: ");
                int numeroBaños = in.nextInt();
                System.out.println("Escribe true si tiene jardin. Si no tiene escribe false: ");
                boolean jardin = in.nextBoolean();
                System.out.println("Pon el precio de la propiedad: ");
                double precio = in.nextDouble();  
                propiedad1 = new Propiedad (numeroReferencia,
                        tipoPropiedad,localizacion,numeroHabitaciones,numeroBaños, jardin, precio);
                verificadorPropiedad = true;
            }
            catch (IllegalArgumentException d){
                System.out.println("Error: "+ d.getMessage());
                System.out.println("Introduce de nuevo los datos");
                in.nextLine();
            }
        }
        System.out.println("\nIntroduce el porcentaje que se llevará la inmobiliaria: ");
        int porcentaje = in.nextInt();
        propiedad1.calculaComision(porcentaje);
        return propiedad1;
    }
    public static void generaInformeComision(Comprador comprador1, Propiedad propiedad1){
        System.out.println(comprador1);
        System.out.println("\n");
        System.out.println(propiedad1);
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Comprador comprador1 = creaComprador();
        Propiedad propiedad1 = creaPropiedad();
        generaInformeComision(comprador1,propiedad1);   
    }
}
