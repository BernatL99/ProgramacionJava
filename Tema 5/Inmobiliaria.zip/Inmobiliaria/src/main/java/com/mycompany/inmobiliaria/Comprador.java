/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inmobiliaria;

/**
 *Creacion de objeto comprador
 * @author Bernat Lopez Munar
 */
public class Comprador {
    private String nombre, telefono, email;
    
    public Comprador(String nombre, String telefono, String email){
        if(nombre.length() < 4 || nombre.length() > 40){
            throw new IllegalArgumentException("El nombre tiene que tener entre 4 y 40 caracteres");
        }
        this.nombre = nombre;
        if(telefono.trim().isEmpty()){
            throw new IllegalArgumentException("EL telefono no puede estar vacío");
        }
        this.telefono = telefono;
        this.email = email;
    }
    
    public String getNombre(){
       return nombre; 
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    
    public String getTelefono(){
        return telefono;
    } 
    public void setTelefono(String telefono){
        this.telefono = telefono;
    }
    
    public String getEmail(){
        return email;
    } 
    public void setEmail(String email){
        this.email = email;
    }
    @Override
    public String toString(){
        return "Comprador:" + "\nNombre: "+ nombre +"\nTelefono: "+ telefono+"\nEmail: "+ email;
    }
}

