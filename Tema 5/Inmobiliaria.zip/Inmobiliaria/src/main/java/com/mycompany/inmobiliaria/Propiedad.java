/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inmobiliaria;

/**
 *Creacion de objeo propiedad
 * @author Bernat Lopez Munar
 */
public class Propiedad {
    private String numeroReferencia, localizacion;
    private TipoPropiedad tipo;
    private int numeroHabitaciones, numeroBaños;
    private boolean jardin;
    private double precio;
    private double comision;
    
    private enum TipoPropiedad{
      PISO, APARTAMENTO, CASA, LOCAL, CASA_RUSTICA, GARAGE, TERRENO, CHALET;  
    }
    
    public Propiedad(String numeroReferencia, String tipo, String localizacion, int numeroHabitaciones,
            int numeroBaños,boolean jardin, double precio){
        if(numeroReferencia.trim().isEmpty()){
            throw new IllegalArgumentException ("El numero de referencia no puede estar vacio ni en blanco");
        }
        this.numeroReferencia = numeroReferencia;
        this.tipo = TipoPropiedad.valueOf(tipo);
        this.localizacion = localizacion;
        this.numeroHabitaciones = numeroHabitaciones;
        this.numeroBaños = numeroBaños;
        this.jardin = jardin;
        if(precio < 0){
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }
        this.precio = precio;  
    }
    
    public String getNumeroReferencia(){
        return numeroReferencia;
    }
    public void setNumeroReferencia(String numeroReferencia){
        this.numeroReferencia = numeroReferencia;
    }
     public TipoPropiedad getTipo(){
        return tipo;
    }
    public void setTipo(TipoPropiedad tipo){
        this.tipo = tipo;
    }
    
    public String getLocalizacion(){
        return localizacion;
    }
    public void setLocalizacion(String localizacion){
        this.localizacion = localizacion;
    }
    
    public int getNumeroHabitaciones(){
        return numeroHabitaciones;
    }
    public void setNumeroHabitaciones(int numeroHabitaciones){
        this.numeroHabitaciones = numeroHabitaciones;
    }
    
    public int getNumeroBaños(){
        return numeroBaños;
    }
    public void setNumeroBaños(int numeroBaños){
        this.numeroBaños = numeroBaños;
    }
    
    public boolean getJardin(){
        return jardin;
    }
    public void setJardin(boolean jardin){
        this.jardin = jardin;
    }
    
    public double getPrecio(){
        return precio;
    }
    public void setPrecio(double precio){
        this.precio = precio;
    }
    
    public void calculaComision(int porcentaje){
        comision = (precio*porcentaje) / 100.00;
    }
   
    
    @Override
    public String toString(){
        return "Inmueble: \nNumero de referencia: "+ numeroReferencia +
                "\nTipo de inmueble: " + tipo+ "\nDirección: "+ localizacion+
                "\nNumero de habitaciones: "+numeroHabitaciones+
                "\nNumero de baños: "+ numeroBaños + "\n¿Tiene jardin? "+ jardin +
                "\nPrecio: "+ precio + "\nLa comision: " + comision;                   
    }
}
