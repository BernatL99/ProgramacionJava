/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gamers;

/**
 *Contiene el objeto Jugador
 * @author Bernat Lopez Munar
 */
import java.time.LocalDate;
public class Jugador {
    private String nombre, alias;
    private int municion;
    private LocalDate fechaAlta;
    private static int contadorJugador = 1;
    
    public Jugador(String nombre, int municion, String alias,LocalDate fechaAlta){
        if(nombre.length() < 5){
            contadorJugador--;
            throw new IllegalArgumentException("El nombre no puede tener menos de 5 carácteres");
        }else if(nombre.length() > 40){
            contadorJugador--;
            throw new IllegalArgumentException("El nombre no puede ser mayor de 40 carácteres");
        }
        this.nombre = nombre;
        if(municion < 0){
            contadorJugador--;
            throw new IllegalArgumentException("La municion no puede ser negativa");
        }
        else if(municion > 50){
            contadorJugador--;
            throw new IllegalArgumentException("La municion no puede superar las 50 unidades");
        }
        this.municion = municion;
        this.alias = alias;
        this.fechaAlta = fechaAlta;
    }
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    
    public int getMunicion(){
        return municion;
    }
    public void setMunicion(int municion){
        if(municion > 50){
            throw new IllegalArgumentException("La municion no puede superar las 50 unidades");
        }
        this.municion = municion;
    }
    
    public String getAlias(){
        return alias;
    }
    public void setAlias(String alias){
        this.alias = alias;
    }
    
    public LocalDate getFechaAlta(){
        return fechaAlta;
    }
    public void setFechaAlta(LocalDate fechaAlta){
        this.fechaAlta = fechaAlta;
    }
    public static int getContadorJugador(){
        int contar = contadorJugador;
        contadorJugador++;
        return contar;
    }
    
    @Override
    public String toString(){
       return  "Jugador: " + "\nNombre: " + nombre + "\nAlias: "+ alias+ "\nMunicion: "+ municion + "\nFecha de creación: " + fechaAlta; 
    }
}
