/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package gamers;

/**
 *Progmara principal para la recolección de datos para el pbjeto jugador
 * @author Bernat Lopez Munar
 */
import java.util.Scanner;
import java.time.LocalDate;
import utilidades.Utilidades;
public class Gamers {
    
    public static Jugador creaNuevoJugador(Jugadores jugadores){
       Scanner in = new Scanner(System.in);
        boolean jugadorCreado = false;
        Jugador jugador = null;
        System.out.println("Bienvenido al creador de jugador: ");
        while(!jugadorCreado){
            try{
                System.out.println("Como se llamara el jugador?");
                String nombre = in.nextLine();
                if(nombre.length() < 4){
                    System.out.println("El nombre no puede ser menot de 5 caracteres");
                } else {
                    String alias = utilidades.Utilidades.demanaCadena(nombre);
                    System.out.println("¿Cuanta munición quieres para tu jugador? \n No puede tener mas de 50 de munición");
                    int municion = utilidades.Utilidades.demanaSencer();
                    LocalDate Date = utilidades.Utilidades.demanaData();
                    jugador = new Jugador(nombre, municion, alias, Date);
                    if(jugadores.addJugadores(jugador)){
                        jugadorCreado = true;   
                    }
                    else{
                        System.out.println("No puedo añadir otro jugador");
                    }
                }
            }
            catch(IllegalArgumentException e){
               System.out.println("Error "+ e.getMessage());
               System.out.println("Introduce correctamente los datos");  
            }
        }
        System.out.println(jugador);
        return jugador;
    }
    
    public static void aumentaMunicion(Jugador j){
        Scanner in = new Scanner(System.in);
        int municion;
        if(j.getMunicion() == 50){
            System.out.println("La municion ya está al máximo");
        }else{
            try{
                System.out.println("La municion actual es de: " + j.getMunicion());
                System.out.println("Cuanto quieres ampliar la munición? \nNo puede superar las 50 unidades");
                municion = in.nextInt();
                municion = municion + j.getMunicion();
                j.setMunicion(municion);
                System.out.println("La municion a augmentado a: " + j.getMunicion());
            }
            catch(IllegalArgumentException e){
                System.out.println("Error" + e.getMessage());
            }
        }  
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        final int Maximo_Jugadores = 20;
        Jugadores jugadores = new Jugadores(Maximo_Jugadores);
        boolean salir = false;
        int eleccionMenu = 0;
        Jugador jugador = null;
        System.out.println("Bienvenido a Gamers");
        while(!salir){
            System.out.println("\n\nMenú: \n1. Crear un nuevo jugador \n2. Ver los datos del jugador \n3. Ver municion de jugadores \n4. Salir");
            eleccionMenu = in.nextInt();
            switch(eleccionMenu){
                case 1:
                    jugador = creaNuevoJugador(jugadores);
                    break;
                case 2:
                    if(jugadores.getNumJugadores() == 0){
                        System.out.println("¡No hay jugadores en la lista!");
                        break;
                    }
                    in.nextLine();
                    System.out.println("Introduce el alias del jugador a buscar: ");
                    String aliasBuscado = in.nextLine();
                    try{
                        Jugador j = jugadores.getJugador(aliasBuscado);
                        System.out.println("\nJugador encontrado\n" + j);
                        
                    }
                    catch(IllegalArgumentException e){
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    if(jugador == null){
                        System.out.println("¡¡¡No ay jugadores creados!!!"); 
                    }
                    else{
                        System.out.println("Revisar munición");
                        System.out.println("Pon la munición que quieres ver:");
                        int municion = in.nextInt();
                        while(municion > 50){
                            System.out.println("No puede ser mayor de 50");
                            municion = in.nextInt();
                        }
                        int contador = jugadores.jugadoresMunicion(municion);
                        System.out.println("La cantidad de jugadores con esa munición o menos es de: " + contador);
                    }
                    break;
                case 4:
                    System.out.println("Salimos del programa, saludos.");
                    salir = true;
                    break;
                default:
                    System.out.println("Tienes que introducir uno de los numeros del menú");       
            }
        }
    }
}
