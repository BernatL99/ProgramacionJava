/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gamers;

/**
 *
 * @author berna
 */
public class Jugadores {
    private Jugador[] jugadores;
    private int numeroJugadores;
    
    public Jugadores(int MaxJugadores){
        this.jugadores = new Jugador[20];
        numeroJugadores = 0;
    }
    
    public Jugador[] getJugadores(){
        Jugador[] nuevo = new Jugador[numeroJugadores];
        for (int i = 0; i < numeroJugadores; i++) {
            nuevo[i] = jugadores[i];
        }
        return nuevo;
    }
    
    public int getNumJugadores(){
        return numeroJugadores;
    }
    public Jugador getJugador(String alias){
        Jugador jugador = null;
        for(int i = 0; i<numeroJugadores;i++){
            if (alias.equals(jugadores[i].getAlias())){
                jugador = jugadores[i];
                return jugador;
            }
        }
        throw new IllegalArgumentException("El jugador con ese alias no existe");
    }
    
    public boolean addJugadores(Jugador nuevo){
        if (numeroJugadores < jugadores.length) {
            jugadores[numeroJugadores] = nuevo;
            numeroJugadores++;
            return true;
        } else {
            return false;
        }
    }
    
    public int jugadoresMunicion(int municion) {
        int contador = 0;
        for(int i = 0;i<numeroJugadores;i++ ){
            if(jugadores[i].getMunicion()<= municion){
                contador++;
            }
        }
        return contador;
    }
}
