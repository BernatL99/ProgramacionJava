/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utilidades;

/**
 *Contiene los metodos para leer los datos 
 * @author Bernat Lopez Munar
 */
import java.time.LocalDate;
import java.util.Scanner;
import gamers.Jugador;
public class Utilidades {
    
    public static int demanaSencer(){
        Scanner in = new Scanner(System.in);
        int sencer = in.nextInt();
        return sencer;
    }
    public static String demanaCadena(String cadena){
        String alias;
        int cantidadJugadores = Jugador.getContadorJugador();
        alias = cadena.substring(0,4) + cantidadJugadores;
        return alias;
    }
    public static LocalDate demanaData(){
        return LocalDate.now();
    }
}
