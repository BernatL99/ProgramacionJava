/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc04ejer01;

/**
 *
 * @author berna
 */
import java.util.Scanner;
import java.text.Normalizer;
public class Bloc04Ejer01 {
    public static String pedirFrase(){
        Scanner in = new Scanner(System.in);
        boolean comprobacion = false;
        String frase = "";
        while(!comprobacion){
            System.out.println("Escriba una frase:");
            frase = in.nextLine();
            if(frase == null || frase.isBlank()){
                System.out.println("Frase en blanco, vuelve a escribir");
                frase = in.nextLine();
            }else{
                comprobacion = true;
            }
        }
        return frase;
    }
    public static char letra(){
        Scanner in = new Scanner(System.in);
        while(true){
            System.out.println("Introdice una letra: ");
            String entradaLetra = in.nextLine();
            if(entradaLetra == null || entradaLetra.isBlank()){
                System.out.println("No puede estar en blanco. Prueba de nuevo");
                continue;
            }
            entradaLetra = entradaLetra.trim();
            if(entradaLetra.length() != 1){
                System.out.println("Solo puede ser un carácter");
                continue;
            }
            char asegurarNoNumero = entradaLetra.charAt(0);
            if(!Character.isLetter(asegurarNoNumero)){
                System.out.println("Debe ser una letra. Prueba de nuevo");
                continue;
            }
            return asegurarNoNumero;
        }    
    }
    
    public static int contarLetra(String frase, char letra){
    String texto = frase.toLowerCase();
    String textoSinAcentos = Normalizer.normalize(texto, Normalizer.Form.NFD);
    int contadorLetra = 0;
    for(int i = 0; i< textoSinAcentos.length(); i++){
        char letraLeida = textoSinAcentos.charAt(i);
        if(letra == letraLeida){
            contadorLetra++; 
        }
    }
    return contadorLetra;
    
}
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        boolean start = true;
        System.out.println("Menu \n1. Crear frase\n2. Cambiar de letra\n3. Salir");
        int indice = in.nextInt();
        String frase = null;
        char letra = '\0';
        int numLetra = 0;
        while(!start){
            switch(indice){
                case 1:
                    frase = pedirFrase();
                    letra = letra();
                    numLetra = contarLetra(frase, letra);
                    System.out.printf("La letra '%c' aparece %d veces. \n", letra, numLetra);
                    break;
                case 2:
                    
                    if (frase == null){
                        System.out.println("No hay frase. Elige la opción 1");
                        break;
                    }else{
                        letra = letra();
                        numLetra = contarLetra(frase, letra);
                        System.out.printf("La letra '%c' aparece %d veces. \n", letra, numLetra);
                        break;
                    }
                case 3:
                    start = false;
                    break;
                    
                default:
                    System.out.println("Elije una de las 3 opciones");
                    System.out.println("Menu \n1. Crear frase\n2. Cambiar de letra\n3. Salir");
            }
            System.out.println("Menu \n1. Crear frase\n2. Cambiar de letra\n3. Salir");
            indice = in.nextInt();
        }
    }
}
