/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc04ejer03;

/**
 * Programa para crear un array bidimensional y extraer una columna
 * @author Bernat López Munar
 */
import java.util.Scanner;
public class Bloc04Ejer03 {

    public static int[][] matriz(){
        Scanner in = new Scanner(System.in);
        int[][]matriz = new int[3][4];
        System.out.println("Vamos a introducir los valores de la matriz");
        for(int i = 0; i < matriz.length; i++){
           for(int j = 0; j < matriz[i].length; j++){
               System.out.println("Pon el número de la coordenada: " + i + ", "+ j);
               matriz[i][j] = in.nextInt();
           }
       }
       return matriz;  
    }
    public static void mostrarMatriz(int[][]matriz){
        for(int i = 0; i< matriz.length; i++){
            for(int j = 0; j< matriz[i].length; j++){
                System.out.printf("%6d", matriz[i][j]);
            }
            System.out.println("");
        }      
    }
        
    public static int[]mostrarColumna(int[][]matriz, int i){
        int[] columna = new int[matriz.length];
        for(int j = 0; j < matriz.length; j++){
            columna[j] = matriz[j][i]; 
        }
        return columna;   
    }
    public static void main(String[] args) {
        int[][] matriz = matriz();
        mostrarMatriz(matriz);
        Scanner in = new Scanner(System.in);
        System.out.println("Selecciona que columna quieres, selecciona de 0 a 3");
        int vector = in.nextInt();
        while(vector< 0 || vector> 3){
            System.out.println("Valor incorrecto, selecciona entre 0 y 3");
            vector = in.nextInt();
        }
        int[]columna = mostrarColumna(matriz, vector);
        System.out.println("Columna: " + vector+ "\n");
        for(int i = 0; i < columna.length; i++){
            System.out.print(columna[i]+", ");
        }
    }
}