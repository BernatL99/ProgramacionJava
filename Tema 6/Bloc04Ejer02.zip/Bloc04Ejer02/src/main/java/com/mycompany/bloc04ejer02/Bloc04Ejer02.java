/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloc04ejer02;

/**
 * Programa para crear una cadéna de texto con letras, simbolo y números para luego comprobar si es correcto
 * @author BernatLópez Munar
 */
import java.util.Scanner;
public class Bloc04Ejer02 {
    public static String[] cadenaDeTexto(){
        Scanner in = new Scanner(System.in);
        String[] cadenaDeTexto = new String[6];
        for(int i = 0; i < cadenaDeTexto.length; i++){
            System.out.println("Introduce una cadena de texto de 3 letras mayúsculas, un guion y 4 números: (AAA-1234)");
            String texto = in.nextLine();
            if(!texto.matches("^[A-Z]{3}-\\d{4}$")){
                while(true){
                    System.out.println("No es correcto. Deben de ser 3 letras mayúsculas, un guion y 4 números: (AAA-1234)");
                    texto = in.nextLine();
                    if(!texto.matches("^[A-Z]{3}-\\d{4}$")){
                        System.out.println("Error!!!");
                    }else{
                        
                        break;
                    }
                }
            }
            cadenaDeTexto[i] = texto; 
        }
        return cadenaDeTexto;
    }
    public static void main(String[] args) {
        String[] cadenaTextoNumeros = cadenaDeTexto();
        String[] cadenaLetras = new String[cadenaTextoNumeros.length];
        int[] cadenaNumeros = new int[cadenaTextoNumeros.length];
        for(int i = 0; i < cadenaTextoNumeros.length;i++){
            cadenaLetras[i]= cadenaTextoNumeros[i].substring(0,3);
            cadenaNumeros[i] = Integer.parseInt(cadenaTextoNumeros[i].substring(4));
        }
        
        System.out.println("Índice\tCódigo\tNúmero");
        for(int i = 0; i <cadenaLetras.length; i++){
            System.out.println(i+"\t"+cadenaLetras[i]+"\t"+cadenaNumeros[i]);
        }
    }
}
