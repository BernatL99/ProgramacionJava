/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion;

/**
 *
 * @author Bernat lópez Munar
 * Creación de la clase Tarea para almacenar los datos necesarios para la tarea
 */
public class Tarea {
    private static int numero = 0;
    private final int codigo;
    private String titulo;
    private String prioridad;
    private String modulo;
    private String fechaCreacion;
    private String fechaEntrega;
    private String estado;
    
    public Tarea() {
        incNumero();
        this.codigo = numero;
    }
    
    private static void incNumero() {
        numero++;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public String getModulo() {
        return modulo;
    }

    public void setModulo(String modulo) {
        this.modulo = modulo;
    }

    public String getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(String fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(String fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Tarea{" + "codigo=" + codigo + ", titulo=" + titulo + ", prioridad=" + prioridad + ", modulo=" + modulo + ", fechaCreacion=" + fechaCreacion + ", fechaEntrega=" + fechaEntrega + ", estado=" + estado + '}';
    } 
}
