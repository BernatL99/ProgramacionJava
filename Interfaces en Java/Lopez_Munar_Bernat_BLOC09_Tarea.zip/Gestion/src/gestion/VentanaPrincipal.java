/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gestion;

import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.text.Collator;
import java.util.Locale;



/**
 * @author Bernat López
 * Código donde se ejecuta el código al interactuar con los botones
 */
public class VentanaPrincipal extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName());
    public VentanaPrincipal() {
        initComponents();
        
        btnActualizar.addActionListener(this::actualizarTarea);
        jButtonOrdenar.addActionListener(this:: jButtonOrdenarActionPerformed);
        jButtonOrdenarModulo.addActionListener(this:: jButtonOrdenarModuloActionPerformed);
        jButtonOrdenarFechaEntr.addActionListener(this:: jButtonOrdenarFechaEntrActionPerformed);
        // Inicializo el arrayList
        listaTareas = new ArrayList<>();
        listaTareasTerminadas = new ArrayList<>();
        // Esto evita que se borre el texto si hay error
        txtFechaEntrega.setFocusLostBehavior(JFormattedTextField.COMMIT_OR_REVERT);
        
        txtFechaCreacion.setText(
                LocalDate.now().format(DateTimeFormatter.ofPattern("d MMM y"))
        );
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtTitulo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        comboPrioridad = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        comboModulo = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        txtFechaCreacion = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtFechaEntrega = new javax.swing.JFormattedTextField();
        btnGuardar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        chkResuelta = new javax.swing.JCheckBox();
        btnBuscar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButtonOrdenar = new javax.swing.JButton();
        jButtonOrdenarModulo = new javax.swing.JButton();
        jButtonOrdenarFechaEntr = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableTareaFinalizada = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Gestión de Tareas - Bernat López\n");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Crear Tarea"));

        jLabel1.setText("Título:");

        jLabel2.setText("Prioridad:");

        comboPrioridad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Alta", "Media", "Baja" }));

        jLabel3.setText("Módulo:");

        comboModulo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Programación", "Bases de datos", "Entornos" }));

        jLabel4.setText("Fecha creación: ");

        txtFechaCreacion.setEditable(false);
        txtFechaCreacion.addActionListener(this::txtFechaCreacionActionPerformed);

        jLabel5.setText("Fecha entrega:");

        txtFechaEntrega.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter()));

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnGuardar)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addGap(18, 18, 18)
                            .addComponent(txtFechaCreacion))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel1)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3))
                            .addGap(28, 28, 28)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(comboModulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtTitulo, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(comboPrioridad, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addGap(27, 27, 27)
                            .addComponent(txtFechaEntrega))))
                .addContainerGap(155, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(comboPrioridad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(comboModulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(txtFechaCreacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtFechaEntrega, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnGuardar)
                .addContainerGap())
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Actualizar Tarea"));

        jLabel6.setText("Código:");

        chkResuelta.setText("Resuelta");

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(this::btnBuscarActionPerformed);

        btnActualizar.setText("Actualizar");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(chkResuelta)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnActualizar))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(37, 37, 37)
                        .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(btnBuscar)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(btnActualizar))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(chkResuelta)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Tareas Pendientes"));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Código", "Título", "Prioridad", "Módulo", "Fecha creación", "Fecha entrega", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jButtonOrdenar.setText("Ordenar por Prioridad");
        jButtonOrdenar.addActionListener(this::jButtonOrdenarActionPerformed);

        jButtonOrdenarModulo.setText("Ordenar por Modulo");

        jButtonOrdenarFechaEntr.setText("Ordenar por Fecha de entrega");
        jButtonOrdenarFechaEntr.addActionListener(this::jButtonOrdenarFechaEntrActionPerformed);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jButtonOrdenar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonOrdenarModulo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonOrdenarFechaEntr))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1151, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(63, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonOrdenar)
                    .addComponent(jButtonOrdenarModulo)
                    .addComponent(jButtonOrdenarFechaEntr))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Tareas Finalizadas"));

        jTableTareaFinalizada.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Código", "Título", "Prioridad", "Módulo", "Fecha creación", "Fecha entrega", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTableTareaFinalizada);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(57, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(698, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(570, 570, 570))
        );

        jPanel4.getAccessibleContext().setAccessibleName("Tareas Terminadas");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtFechaCreacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaCreacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFechaCreacionActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed

        try {
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("d MMM y");
            String textoFecha = txtFechaEntrega.getText();
            
            if (textoFecha.trim().isEmpty()) {
                throw new Exception("La fecha de entrega no puede estar vacía.");
            }
            LocalDate fechaValida = LocalDate.parse(textoFecha, formato);
            
            Tarea t = new Tarea();
            
            t.setTitulo(txtTitulo.getText());
            t.setPrioridad(comboPrioridad.getSelectedItem().toString());
            t.setModulo(comboModulo.getSelectedItem().toString());
            t.setFechaCreacion(txtFechaCreacion.getText());
            t.setFechaEntrega(txtFechaEntrega.getText());
            t.setEstado("pendiente");
            System.out.println("Tarea Creada Correctamente: " + t.getCodigo());
            System.out.println(t);
            listaTareas.add(t);
            
            boolean tablaActualizada = actualizarTabla();

            if(tablaActualizada){
                JOptionPane.showMessageDialog(this,
                        "Tarea agregada correctamente");
            }
            
            limpiarCampos();
            
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Formato de fecha incorrecto. Debe ser: 18 abr 2026",
                    "Error de Validación",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
            txtFechaEntrega.requestFocus();
            txtFechaEntrega.selectAll();
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed

        try {
            int codigoBuscado = Integer.parseInt(txtCodigo.getText());
            
            tareaSeleccionada = null;
            
            for (Tarea t : listaTareas) {
                if (t.getCodigo() == codigoBuscado) {
                    tareaSeleccionada = t;

                    if (t.getEstado().equalsIgnoreCase("resuelta")) {
                        chkResuelta.setSelected(true);
                    } else {
                        chkResuelta.setSelected(false);
                    }
                    
                    javax.swing.JOptionPane.showMessageDialog(this, "Tarea encontrada");
                    
                    return;
                }
                
            }
            
            javax.swing.JOptionPane.showMessageDialog(this, "Código no existe!");
            
            txtCodigo.setText("");
            
        } catch (Exception e) {
            
            javax.swing.JOptionPane.showMessageDialog(this, "Código inválido!");    
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void jButtonOrdenarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonOrdenarActionPerformed
        if(listaTareas == null){
            JOptionPane.showMessageDialog(this,
                    "No hay tareas creadas");
        }
        else{
            
            for(int i = 0; i< listaTareas.size()-1;i++){
                for(int j = i+1; j<listaTareas.size(); j++){
                    int prioridadTarea1 = 0;
                    int prioridadTarea2 = 0;
                    
                    Tarea t1 = listaTareas.get(i);
                    Tarea t2 = listaTareas.get(j);
                    
                    String tarea1 = t1.getPrioridad();
                    prioridadTarea1 = nivelDePrioridad(tarea1);
                    
                    String tarea2 = t2.getPrioridad();
                    prioridadTarea2 = nivelDePrioridad(tarea2);
                    
                    if(prioridadTarea1 < prioridadTarea2 ){
                        listaTareas.set(i, t2);
                        listaTareas.set(j,t1);
                    }
                }
            }
            actualizarTabla();
        }
    }//GEN-LAST:event_jButtonOrdenarActionPerformed

    private void jButtonOrdenarModuloActionPerformed(java.awt.event.ActionEvent evt) {
        String modulo = null;
        Collator collator = Collator.getInstance(new Locale("es","ES"));
        listaTareas.sort((t1,t2) -> //Uso de lamda para crear ka función de manera rápida
            collator.compare(t1.getModulo(), t2.getModulo()));
        actualizarTabla();
    }   
    private void jButtonOrdenarFechaEntrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonOrdenarFechaEntrActionPerformed
        for(int i = 0; i < listaTareas.size() -1 ; i++){
            for(int j = i+1; j < listaTareas.size(); j++){
                Tarea t1 = listaTareas.get(i);
                Tarea t2 = listaTareas.get(j);
                
                String fechaEntrega1 = t1.getFechaEntrega();
                String fechaEntrga2 = t2.getFechaEntrega();
                
                DateTimeFormatter formatter =
                        DateTimeFormatter.ofPattern("d MMM y", new Locale("es", "ES"));
                
                LocalDate fecha1 = LocalDate.parse(fechaEntrega1, formatter);
                LocalDate fecha2 = LocalDate.parse(fechaEntrga2, formatter);
                if(fecha2.isBefore(fecha1)){
                    listaTareas.set(j, t1);
                    listaTareas.set(i, t2);
                }    
            }
        }
        actualizarTabla();
    }//GEN-LAST:event_jButtonOrdenarFechaEntrActionPerformed
    private boolean actualizarTabla() {
        DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();
        
        modelo.setRowCount(0);
        
        for (Tarea t : listaTareas) {
            if (t.getEstado().equalsIgnoreCase("pendiente")) {
                Object[] fila = {
                        t.getCodigo(),
                        t.getTitulo(),
                        t.getPrioridad(),
                        t.getModulo(),
                        t.getFechaCreacion(),
                        t.getFechaEntrega(),
                        t.getEstado()
                };
                
                modelo.addRow(fila);
            }
        }
        return true;
    }
    
    private void limpiarCampos() {
        
        txtTitulo.setText("");
        comboPrioridad.setSelectedIndex(0);
        comboModulo.setSelectedIndex(0);
        txtFechaEntrega.setText("");
        txtFechaCreacion.setText(
                LocalDate.now().format(DateTimeFormatter.ofPattern("d MMM y"))
        );  
        txtTitulo.requestFocus();
    }

    private void actualizarTarea(java.awt.event.ActionEvent evt) {
  
        if (tareaSeleccionada == null) {
                JOptionPane.showMessageDialog(this,
                        "Primero debes buscar una tarea");
                return;
            }

            if (!chkResuelta.isSelected()) {
                JOptionPane.showMessageDialog(this,
                        "Marca la tarea como resuelta para borrarla");
                return;
            }

            int option = JOptionPane.showConfirmDialog(
                    this,
                    "¿Seguro que quieres borrar la tarea?",
                    "Confirmar",
                    JOptionPane.YES_NO_OPTION
            );

            if (option != JOptionPane.YES_OPTION) {
                return;
            }

            Tarea t1 = tareaSeleccionada;
            listaTareas.remove(tareaSeleccionada);
            String pendiente = "Finalizado";
            t1.setEstado(pendiente);
            listaTareasTerminadas.add(t1);

            tareaSeleccionada = null;
            txtCodigo.setText("");
            chkResuelta.setSelected(false);

            boolean tablaActualizada = actualizarTabla();

            if(tablaActualizada){
                JOptionPane.showMessageDialog(this,
                        "Tarea eliminada correctamente");
            }
            actualizarTablaTareaFinalizada();
            
    }
    
    private int nivelDePrioridad(String prioridadTarea){
        int prioridadTareaNum = 0;
        switch(prioridadTarea){
            case "Alta":
                prioridadTareaNum = 3;
                break;
            case "Media":
                prioridadTareaNum = 2;
                break;
            case "Baja":
                prioridadTareaNum = 1;
                break;
        }
        return prioridadTareaNum;   
    }   

    private void actualizarTablaTareaFinalizada() {
         DefaultTableModel modelo = (DefaultTableModel) jTableTareaFinalizada.getModel();
       
        modelo.setRowCount(0);
        for (Tarea t : listaTareasTerminadas) {
            Object[] fila = {
                    t.getCodigo(),
                    t.getTitulo(),
                    t.getPrioridad(),
                    t.getModulo(),
                    t.getFechaCreacion(),
                    t.getFechaEntrega(),
                    t.getEstado()
            };

            modelo.addRow(fila);
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JCheckBox chkResuelta;
    private javax.swing.JComboBox<String> comboModulo;
    private javax.swing.JComboBox<String> comboPrioridad;
    private javax.swing.JButton jButtonOrdenar;
    private javax.swing.JButton jButtonOrdenarFechaEntr;
    private javax.swing.JButton jButtonOrdenarModulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTableTareaFinalizada;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtFechaCreacion;
    private javax.swing.JFormattedTextField txtFechaEntrega;
    private javax.swing.JTextField txtTitulo;
    // End of variables declaration//GEN-END:variables

    private ArrayList<Tarea> listaTareas = null;
    private Tarea tareaSeleccionada = null;
    private ArrayList<Tarea> listaTareasTerminadas = null;
}
